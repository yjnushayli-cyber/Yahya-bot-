export type LatestSignal = {
  asset_id: number;
  signal: 'CALL' | 'PUT' | 'SKIP';
  confidence: number;
  reason: string;
  current_time: string | null;
  entry_time: string | null;
  exit_time: string | null;
  status_text: string;
};

import { NextResponse } from 'next/server';

export async function GET() {
  const workerUrl = process.env.WORKER_URL;
  if (!workerUrl) {
    return NextResponse.json({
      asset_id: 240,
      signal: 'SKIP',
      confidence: 0,
      reason: 'لم يتم ضبط رابط الـ worker بعد',
      current_time: null,
      entry_time: null,
      exit_time: null,
      status_text: 'انتظر'
    });
  }

  try {
    const res = await fetch(`${workerUrl.replace(/\/$/, '')}/latest-signal`, { cache: 'no-store' });
    const data = await res.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({
      asset_id: 240,
      signal: 'SKIP',
      confidence: 0,
      reason: 'تعذر الوصول إلى محرك الإشارات',
      current_time: null,
      entry_time: null,
      exit_time: null,
      status_text: 'انتظر'
    }, { status: 200 });
  }
}

import Dashboard from '@/components/Dashboard';

export default function HomePage() {
  return (
    <main className="page">
      <Dashboard />
    </main>
  );
}

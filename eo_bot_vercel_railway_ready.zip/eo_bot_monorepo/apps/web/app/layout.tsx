import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'EO Signal Bot',
  description: 'واجهة إشارات كل دقيقة',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}

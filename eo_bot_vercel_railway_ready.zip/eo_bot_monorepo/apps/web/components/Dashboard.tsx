'use client';

import { useEffect, useMemo, useState } from 'react';
import type { LatestSignal } from '@/lib/types';

const initialState: LatestSignal = {
  asset_id: 240,
  signal: 'SKIP',
  confidence: 0,
  reason: 'جاري التحميل',
  current_time: null,
  entry_time: null,
  exit_time: null,
  status_text: 'انتظر',
};

export default function Dashboard() {
  const [data, setData] = useState<LatestSignal>(initialState);
  const [localNow, setLocalNow] = useState<string>('');
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState('');

  async function loadLatest() {
    const res = await fetch('/api/latest', { cache: 'no-store' });
    const json = await res.json();
    setData(json);
  }

  useEffect(() => {
    loadLatest();
    const i = setInterval(loadLatest, 5000);
    const j = setInterval(() => {
      setLocalNow(new Date().toLocaleString('ar-SA'));
    }, 1000);
    return () => {
      clearInterval(i);
      clearInterval(j);
    };
  }, []);

  const signalClass = useMemo(() => `signal-${data.signal}`, [data.signal]);

  async function onUpload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setUploading(true);
    setMessage('');
    const form = new FormData(e.currentTarget);
    const workerUrl = (process.env.NEXT_PUBLIC_WORKER_URL || '').replace(/\/$/, '');
    if (!workerUrl) {
      setMessage('أضف NEXT_PUBLIC_WORKER_URL في Vercel أولًا');
      setUploading(false);
      return;
    }
    const res = await fetch(`${workerUrl}/upload-capture`, { method: 'POST', body: form });
    const json = await res.json();
    if (json.ok) {
      setMessage(`تم التحليل: ${json.candles_1m} شمعة دقيقة، ${json.evaluations} تقييمات`);
      await loadLatest();
    } else {
      setMessage(json.error || 'فشل التحليل');
    }
    setUploading(false);
  }

  return (
    <div className="wrap">
      <div className="card">
        <h1>بوت إشارات EO</h1>
        <p className="muted">واجهة Vercel + محرك Railway</p>
      </div>

      <div className="grid">
        <div className="card"><div className="label">وقت الجوال الآن</div><div className="value">{localNow || '...'}</div></div>
        <div className="card"><div className="label">السوق</div><div className="value">SMARTY / {data.asset_id}</div></div>
        <div className="card"><div className="label">الإشارة</div><div className={`value ${signalClass}`}>{data.signal}</div></div>
        <div className="card"><div className="label">الثقة</div><div className="value">{data.confidence}%</div></div>
        <div className="card"><div className="label">بداية الصفقة</div><div className="value">{data.entry_time || '—'}</div></div>
        <div className="card"><div className="label">نهاية الصفقة</div><div className="value">{data.exit_time || '—'}</div></div>
      </div>

      <div className="card">
        <div className="label">الحالة</div>
        <div className="value">{data.status_text}</div>
        <p className="muted">{data.reason}</p>
      </div>

      <div className="card">
        <h2>رفع ملف Capture وتحليله</h2>
        <form onSubmit={onUpload}>
          <input type="hidden" name="asset_id" value="240" />
          <input type="file" name="file" accept=".json" required />
          <div style={{height: 12}} />
          <button disabled={uploading}>{uploading ? 'جاري التحليل...' : 'ارفع الملف وحلل'}</button>
        </form>
        {message ? <p className="muted">{message}</p> : null}
      </div>
    </div>
  );
}

from __future__ import annotations
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, UploadFile
from pydantic import BaseModel

from .parser import extract_ticks_and_ohlc, build_1m_candles
from .storage import CANDLES, HISTORY, LATEST, read_json, save_json
from .strategy import Candle, evaluate_signal

TZ = timezone(timedelta(hours=3))
APP_ROOT = Path(__file__).resolve().parents[1]
SAMPLE = APP_ROOT / "sample_data" / "sample_capture.json"

app = FastAPI(title="EO Signal Worker", version="1.0.0")


class ReplayRequest(BaseModel):
    asset_id: int = 240
    file_path: Optional[str] = None


def _fmt(ts: int) -> str:
    return datetime.fromtimestamp(ts, tz=TZ).strftime("%Y-%m-%d %H:%M:%S")


def _replay(path: Path, asset_id: int) -> dict:
    rows = extract_ticks_and_ohlc(path, asset_id)
    candle_rows = build_1m_candles(rows)
    candles = [Candle(**c) for c in candle_rows]
    history = []

    for i in range(14, len(candles)):
        subset = candles[: i + 1]
        signal = evaluate_signal(subset)
        current_minute = subset[-1].ts
        entry = current_minute + 60
        exit_ = entry + 60
        item = {
            "asset_id": asset_id,
            "signal": signal.signal,
            "confidence": signal.confidence,
            "reason": signal.reason,
            "current_time": _fmt(current_minute),
            "entry_time": _fmt(entry),
            "exit_time": _fmt(exit_),
            "status_text": "ادخل الآن" if signal.signal in ("CALL", "PUT") else "انتظر",
        }
        history.append(item)

    latest = history[-1] if history else {
        "asset_id": asset_id,
        "signal": "SKIP",
        "confidence": 0,
        "reason": "لا توجد بيانات كافية حتى الآن",
        "current_time": None,
        "entry_time": None,
        "exit_time": None,
        "status_text": "انتظر",
    }
    save_json(CANDLES, candle_rows)
    save_json(HISTORY, history)
    save_json(LATEST, latest)
    return {
        "ok": True,
        "rows": len(rows),
        "candles_1m": len(candle_rows),
        "evaluations": len(history),
        "latest_signal": latest,
    }


@app.get("/health")
def health() -> dict:
    return {"ok": True}


@app.get("/latest-signal")
def latest_signal() -> dict:
    return read_json(LATEST, {
        "asset_id": 240,
        "signal": "SKIP",
        "confidence": 0,
        "reason": "لم يتم تشغيل التحليل بعد",
        "current_time": None,
        "entry_time": None,
        "exit_time": None,
        "status_text": "انتظر",
    })


@app.get("/signals-history")
def signals_history() -> list:
    return read_json(HISTORY, [])


@app.post("/replay-sample")
def replay_sample(asset_id: int = 240) -> dict:
    if not SAMPLE.exists():
        return {"ok": False, "error": "sample file missing"}
    return _replay(SAMPLE, asset_id)


@app.post("/replay-file")
def replay_file(payload: ReplayRequest) -> dict:
    if not payload.file_path:
        return {"ok": False, "error": "file_path is required"}
    path = Path(payload.file_path)
    if not path.exists():
        return {"ok": False, "error": "file not found"}
    return _replay(path, payload.asset_id)


@app.post("/upload-capture")
async def upload_capture(asset_id: int = Form(240), file: UploadFile = File(...)) -> dict:
    uploads = APP_ROOT / "uploads"
    uploads.mkdir(exist_ok=True)
    dst = uploads / file.filename
    data = await file.read()
    dst.write_bytes(data)
    return _replay(dst, asset_id)

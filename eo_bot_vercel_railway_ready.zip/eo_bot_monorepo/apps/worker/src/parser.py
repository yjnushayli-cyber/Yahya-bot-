from __future__ import annotations
import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List


def _load_capture(path: str | Path) -> Dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def extract_ticks_and_ohlc(path: str | Path, asset_id: int) -> List[dict]:
    data = _load_capture(path)
    out: List[dict] = []
    for event in data.get("events", []):
        if event.get("type") != "ws_inbound":
            continue
        preview = event.get("textPreview")
        if not preview or '"action":"candles"' not in preview:
            continue
        try:
            payload = json.loads(preview)
        except Exception:
            continue
        msg = payload.get("message", {})
        if msg.get("assetId") != asset_id:
            continue
        candles = msg.get("candles", [])
        if not candles:
            continue
        row: dict = {"event_ts": event.get("ts")}
        for item in candles:
            tf = item.get("tf")
            vals = item.get("v", [])
            row[f"tf_{tf}"] = {"t": item.get("t"), "tt": item.get("tt"), "v": vals}
        out.append(row)
    return out


def build_1m_candles(rows: List[dict]) -> List[dict]:
    buckets: dict[int, dict] = defaultdict(dict)
    for row in rows:
        tick = row.get("tf_0")
        if not tick:
            continue
        t = tick.get("t")
        vals = tick.get("v") or []
        if t is None or not vals:
            continue
        price = float(vals[0])
        minute = int(t) // 60 * 60
        b = buckets.get(minute)
        if not b:
            buckets[minute] = {
                "ts": minute,
                "open": price,
                "high": price,
                "low": price,
                "close": price,
            }
        else:
            b["high"] = max(b["high"], price)
            b["low"] = min(b["low"], price)
            b["close"] = price
    return [buckets[k] for k in sorted(buckets.keys())]

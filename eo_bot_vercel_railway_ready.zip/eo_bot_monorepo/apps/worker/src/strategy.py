from __future__ import annotations
from dataclasses import dataclass
from typing import List, Literal

SignalType = Literal["CALL", "PUT", "SKIP"]

@dataclass
class Candle:
    ts: int
    open: float
    high: float
    low: float
    close: float

@dataclass
class SignalResult:
    signal: SignalType
    confidence: int
    reason: str


def ema(values: List[float], period: int) -> List[float]:
    if not values:
        return []
    alpha = 2 / (period + 1)
    out = [values[0]]
    for v in values[1:]:
        out.append(alpha * v + (1 - alpha) * out[-1])
    return out


def rsi(values: List[float], period: int = 14) -> List[float]:
    if len(values) < 2:
        return [50.0] * len(values)
    gains = [0.0]
    losses = [0.0]
    for i in range(1, len(values)):
        delta = values[i] - values[i - 1]
        gains.append(max(delta, 0.0))
        losses.append(abs(min(delta, 0.0)))

    out: List[float] = [50.0] * len(values)
    avg_gain = sum(gains[1: period + 1]) / max(period, 1)
    avg_loss = sum(losses[1: period + 1]) / max(period, 1)
    for i in range(period, len(values)):
        if i > period:
            avg_gain = ((avg_gain * (period - 1)) + gains[i]) / period
            avg_loss = ((avg_loss * (period - 1)) + losses[i]) / period
        rs = avg_gain / avg_loss if avg_loss else 999.0
        out[i] = 100 - (100 / (1 + rs))
    return out


def atr(candles: List[Candle], period: int = 14) -> List[float]:
    if not candles:
        return []
    trs: List[float] = [candles[0].high - candles[0].low]
    for i in range(1, len(candles)):
        c = candles[i]
        prev_close = candles[i - 1].close
        tr = max(c.high - c.low, abs(c.high - prev_close), abs(c.low - prev_close))
        trs.append(tr)
    out = [trs[0]]
    for i in range(1, len(trs)):
        prev = out[-1]
        out.append(((prev * (period - 1)) + trs[i]) / period)
    return out


def evaluate_signal(candles: List[Candle]) -> SignalResult:
    if len(candles) < 15:
        return SignalResult("SKIP", 0, "البيانات غير كافية بعد")

    closes = [c.close for c in candles]
    ema9 = ema(closes, 9)
    ema21 = ema(closes, 21)
    rsi14 = rsi(closes, 14)
    atr14 = atr(candles, 14)

    last = candles[-1]
    prev = candles[-2]

    trend_up = ema9[-1] > ema21[-1]
    trend_down = ema9[-1] < ema21[-1]
    momentum_up = rsi14[-1] >= 54
    momentum_down = rsi14[-1] <= 46
    body = abs(last.close - last.open)
    total_range = max(last.high - last.low, 1e-9)
    body_ratio = body / total_range
    atr_ok = atr14[-1] > max((sum(atr14[-5:]) / min(5, len(atr14))), 1e-9) * 0.65
    broke_prev_high = last.close > prev.high
    broke_prev_low = last.close < prev.low

    score_up = 0
    score_down = 0

    if trend_up:
        score_up += 25
    if trend_down:
        score_down += 25
    if momentum_up:
        score_up += 20
    if momentum_down:
        score_down += 20
    if body_ratio >= 0.55:
        if last.close > last.open:
            score_up += 20
        elif last.close < last.open:
            score_down += 20
    if atr_ok:
        if trend_up:
            score_up += 15
        if trend_down:
            score_down += 15
    if broke_prev_high:
        score_up += 20
    if broke_prev_low:
        score_down += 20

    if max(score_up, score_down) < 55:
        return SignalResult("SKIP", max(score_up, score_down), "السوق غير واضح أو الزخم ضعيف")
    if abs(score_up - score_down) < 15:
        return SignalResult("SKIP", max(score_up, score_down), "التعارض بين الاتجاه والزخم مرتفع")
    if score_up > score_down:
        return SignalResult("CALL", min(score_up, 95), "اتجاه صاعد + زخم + كسر قمة سابقة")
    return SignalResult("PUT", min(score_down, 95), "اتجاه هابط + زخم + كسر قاع سابق")

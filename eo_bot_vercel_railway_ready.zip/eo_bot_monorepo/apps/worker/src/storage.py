from __future__ import annotations
import json
from pathlib import Path
from typing import Any

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "runtime"
DATA.mkdir(exist_ok=True)
LATEST = DATA / "latest_signal.json"
HISTORY = DATA / "signals_history.json"
CANDLES = DATA / "candles_1m.json"


def save_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))
